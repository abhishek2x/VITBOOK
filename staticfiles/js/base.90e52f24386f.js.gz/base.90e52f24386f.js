function validate(){
    var u = document.getElementById("theme").value;
    
        alert("Theme changer");
        u.style.border = "solid 13px red";
        // document.getElementById("check").style.visibility = "visible";

}