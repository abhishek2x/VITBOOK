
window.onload = function () {
    var typed = new Typed('#typed', {
        strings: ["Welcome to Vitbook", "SOCIAL MEDIA <br> PLATFORM FOR VITIANS", "Explore Vithub", "Access TechEra", "Develop Connections", "Get Social", "Make Communities and <br> Forums"],
        backSpeed: 15,
        smartBackspace: true,
        backDelay: 1200,
        startDelay: 1000,
        typeSpeed: 40,
        loop: true,
    });
};
